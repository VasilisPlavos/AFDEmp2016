
public class Driver {
	private Car car;
	private DrivingLicense license;
}
