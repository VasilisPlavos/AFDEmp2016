
public class Car {
	private CarLicense license;
}
