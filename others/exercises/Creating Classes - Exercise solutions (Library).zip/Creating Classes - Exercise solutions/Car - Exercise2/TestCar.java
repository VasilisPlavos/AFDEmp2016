
public class TestCar {
	public static void main(String args[]) {
		System.out.println("It compiles, Yey!!");
	}
}
