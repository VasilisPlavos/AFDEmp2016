
public class Library {
	private Book[] books;

	/** Constructors */
	public Library() {}
	public Library(Book[] books) {
		super();
		this.books = books;
	}
	
	/** Getters and Setters */
	public Book[] getBooks() { return books; }
	public void setBooks(Book[] books) { this.books = books; }
	
	public void printAvailableBooks() {
		System.out.println("The following books are available at the library for renting");
		int count = 1;
		for(int i=0; i<this.books.length; i++) {
			if (this.books[i].isAvailable()) {
				System.out.println(count++ + ". " + this.books[i].toString());
			}
		}
	}
	
	public void printBookDetails(String book_title) {
		for(int i=0; i<this.books.length; i++) {
			if (this.books[i].getTitle().equals(book_title)) {
				System.out.println("Book found in the library!\n" + this.books[i].toString());
				return;
			}
		}
		System.out.println("Book \"" + book_title + "\" not found. Please search with another title." );
	}
	
	public void printBookFromAuthor(String author_name) {
		System.out.println("Books by author \"" + author_name + "\":");
		int count = 1;
		for(int i=0; i<this.books.length; i++) {
			if (this.books[i].hasAuthor(author_name)) {
				System.out.println(count++ + ". " + this.books[i].toString());
			}
		}
	}
}
