

public class BootCampCandidates {
	
	//Create three private fields a name a surname and age
	
	
	//Create a constructor that receives three arguments and initializes the variables

	
	//Create getters and setters for all your variables (six in total methods needed)

	
	//Create a method toString that returns the name surname and age of the candidate


}
