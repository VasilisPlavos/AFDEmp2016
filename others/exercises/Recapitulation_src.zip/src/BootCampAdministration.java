

import java.util.ArrayList;

public class BootCampAdministration {

	//Create a private ArrayList with object of BootCampCandidates with name anArrayListOfBootCamps

	
	//Create a constructor which receives an array with BootCampCandidate objects and 
	//initializes the anArrayListOfBootCamps ArrayList by adding all BootCampCandidate array's
	//elements in the the nArrayListOfBootCamps

	
	//Create setters and getters for BootCampAdministration

	

	//create an int method that returns the size of anArrayListOfBootCamps

	
	//Create a method that adds a new BootCampCandidate inside the ArrayList

	
	//Create a method that removes a candidate by name and returns true if found or false if not
	//HINT: you have to use get() to get the object and equals to compare it

	
	//Create a method to search for a boot camp member by surname and returns a string with its information
	// if it's found and null if it's not found

	
	
	//Create a method that can change a bootcampers age by having as input its name and surname

	
}
