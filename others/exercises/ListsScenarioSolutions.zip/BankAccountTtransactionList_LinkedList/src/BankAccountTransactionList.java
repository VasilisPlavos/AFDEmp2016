import java.util.ArrayList;

/***
 * This class represents a list of a bank accounts' transactions.
 * For storing the Transactions we implement the BankAccountTransactionList
 * class a LinkedList. 
 */
public class BankAccountTransactionList {
	/* Represents the first element of the Linked-list. It's the only that needs
	 * to be stored in the class. All the rest can be found by traversing the list 
	 * using first as your starting point. */
	private BankAccountTransaction first;

	/* The default constructor. or safety reasons (avoid NullPointerException) 
	 * we have to initialize the bankAccountTransactions object. */
	public BankAccountTransactionList() {
		/* You can ommit the following initialization since 
		 * this.next is, by default initialized as "null" */
		this.first = null;
	}
	

	/* Adds a new transaction at the last position of the 
	 * bankAccountTransactions Linked-list. */
	public void add(BankAccountTransaction new_transaction) {
		// if the first element is "null" then we only need to assign the 
		// new_transaction to the first element. No actions need to be performed
		// and thus, we exit the method by using a return statement. 
		// (yes, return in a void method!)
		if(this.first == null) {
			this.first = new_transaction;
		// if the check statement above is false, it means that at least one
		// element already exists in our list. in that case we need to traverse
		// the list until we find an element that has his "next" reference 
		// showing to "null", that means this element is the last in the list.
		} else {
			BankAccountTransaction current_transaction = this.first;
			while (current_transaction.getNext() != null) {
				current_transaction = current_transaction.getNext();
			}
			// After finding the last element of the list we only need to assign 
			// the new_transaction to the "next" of this element.
			current_transaction.setNext(new_transaction);
		}
		
	}
	
	/* Adds a new element at a specific position (index) of the list */
	public void add(int index, BankAccountTransaction new_transaction) {
		// This check exists in order to avoid the case that you try to remove an
		// element in a position out_of_bounds of your list. out_of_bounds
		// can happen at the left and the right of your list.
		if(index < 0 || index > this.getNumberOfStoredTransactions() - 1) {
			return;
		// If you try to add at the beginning 	
		// keep the current first in a temp object
		// set the new_transaction as first
		// set the "next" of the new first as the old first!
		} else if (index == 0) {
			BankAccountTransaction temp = this.first;
			this.first = new_transaction;
			this.first.setNext(temp);
		// if you try to add at the end of the list
		// it behaves as a normal add and thus, it calls the simple add() method 
		} else if (index == this.getNumberOfStoredTransactions() - 1) {
			this.add(new_transaction);
		// In any other case you need to traverse the list for as many times as
		// is requested (by index) and retrieve the element at that position.
		} else {
			BankAccountTransaction current_transaction = this.first;
			for (int counter = 1; counter < index - 1; counter++) {
				current_transaction = current_transaction.getNext();
			}
			// Store the "next" of the current element in a temp object
			BankAccountTransaction temp = current_transaction.getNext();
			// assign the new_transaction as "next" to the current element
			current_transaction.setNext(new_transaction);
			// assign the temp element as the next of the new_transaction
			new_transaction.setNext(temp);
		}
		
	}
	
	/* Removes the last element of the bankAccountTransactions Linked-list. */
	public void remove() {
		// if the first element is "null" then no actions need to be performed
		// and thus, we exit the method by using a return statement. 
		// (yes, return in a void method!)
		if(this.first == null) {
			return;
		// If the first element exists but has no next it means that we just need 
		// to set the first as null. We then, exit the method.
		} else if(this.first.getNext() == null) {
			this.first = null;
			return;
		// if the check statements above are false, it means that at least two
		// elements already exists in our list. in that case we need to traverse
		// the list until we find an element that has his "next"."next" reference 
		// showing to "null", that means this element is the previous to the last in the list.
		} else {
			BankAccountTransaction current_transaction = this.first;
			while (current_transaction.getNext().getNext() != null) {
				current_transaction = current_transaction.getNext();
			}
			// After finding the previous to the last element of the list we only need to 
			// set its "next" as "null"
			current_transaction.setNext(null);
		}
	}
	
	/* removes an element at a specific position (index) of the list */
	public void remove(int index) {
		// This check exists in order to avoid the case that you try to remove an
		// element in a position out_of_bounds of your list. out_of_bounds
		// can happen at the left and the right of your list.
		if(index < 0 || index > this.getNumberOfStoredTransactions() - 1) {
			return;
		// If you try to remove the element at the beginning 	
		// you just need to set the "next" of the first element as 
		// the first element
		} else if (index == 0) {
			this.first = this.first.getNext();
		// if you try to remove the element at the end of the list
		// it behaves as a normal remove and thus, it calls the simple remove() method 
		} else if (index == this.getNumberOfStoredTransactions() - 1) {
			this.remove();
		// In any other case you need to traverse the list for as many times as
		// is requested (by index) and retrieve the element at that position.
		} else {
			BankAccountTransaction current_transaction = this.first;
			for (int counter = 1; counter < index; counter++) {
				current_transaction = current_transaction.getNext();
			}
			// assign the "next"."next" of your current_transaction as 
			// "next". That way. you simply bypass the next element
			current_transaction.setNext(current_transaction.getNext().getNext());
		}
		
	}
	
	/* Returns the number of the stored Transactions 
	 * We need to traverse the list in order to count the elements */
	public int getNumberOfStoredTransactions() {
		// if the first element is "null" then the size is 0. 
		if(this.first == null) {
			return 0;
		// if the check statement above is false, it means that at least one
		// element already exists in our list. in that case we need to traverse
		// the list until we find an element that has his "next" reference 
		// showing to "null", that means this element is the last in the list.
		} else {
			// declare and initialize counter to 1 since the first element "exists" 
			// (is not "null")
			int counter = 1;
			BankAccountTransaction current_transaction = this.first;
			while (current_transaction.getNext() != null) {
				current_transaction = current_transaction.getNext();
				// increase counter by one for each existing element
				counter += 1;
			}
			return counter;
		}
	}
	
	/* prints all stored BankAccountTransaction */
	public void print() {
		// if the first element is "null" then the list is empty and there is nothing to print. 
		// No further actions need to be performed and thus, we exit the method by using 
		// a return statement. (yes, return in a void method!)
		if(this.first == null) {
			return;
		// if the check statement above is false, it means that at least one
		// element already exists in our list. in that case we need to traverse
		// the list until we find an element that has his "next" reference 
		// showing to "null", that means this element is the last in the list.
		} else {
			int counter = 1;
			BankAccountTransaction current_transaction = this.first;
			// Note that in this method, our while loop is executed for 
			// as long as current_transaction is not "null" and not like in the previous cases
			// (where the .getNext() != null)
			while (current_transaction != null) {
				System.out.println((counter++) + ". " + current_transaction.toString());
				current_transaction = current_transaction.getNext();
				// increase counter by one for each existing element
			}
			System.out.println("==============================================");
		}
	}
	
	
}
